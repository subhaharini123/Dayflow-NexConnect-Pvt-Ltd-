export type LeaveType = 'Paid Time Off' | 'Sick Time Off' | 'Unpaid Leave';

export type LeaveStatus = 'Pending' | 'Approved' | 'Rejected';

export interface LeaveBalance {
  paidTimeOffTotal: number;
  paidTimeOffUsed: number;
  sickTimeOffTotal: number;
  sickTimeOffUsed: number;
  unpaidLeaveUsed: number;
}

export interface Employee {
  id: string;
  name: string;
  email: string;
  roleTitle: string;
  department: string;
  avatar: string;
  isHRAdmin: boolean;
  balances: LeaveBalance;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeEmail: string;
  employeeDepartment: string;
  employeeAvatar: string;
  leaveType: LeaveType;
  startDate: string; // ISO format: YYYY-MM-DD
  endDate: string;   // ISO format: YYYY-MM-DD
  days: number;
  reason: string;
  status: LeaveStatus;
  createdAt: string; // ISO date string
  reviewedBy?: string;
  reviewedAt?: string;
  adminComments?: string;
  attachmentName?: string;
  attachmentSize?: string;
}

export type ActiveNavTab = 'employees' | 'attendance' | 'time-off';
