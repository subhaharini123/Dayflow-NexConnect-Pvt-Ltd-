import React from 'react';
import { Employee } from '../types';
import { Clock, CheckCircle2, AlertCircle, Calendar } from 'lucide-react';

interface AttendanceViewProps {
  employees: Employee[];
  onNavigateToTimeOff: () => void;
}

export const AttendanceView: React.FC<AttendanceViewProps> = ({
  employees,
  onNavigateToTimeOff,
}) => {
  return (
    <div id="attendance-page-container" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Attendance</h1>
          <p className="text-xs text-slate-500 mt-1">
            Daily check-in logs and work hours overview
          </p>
        </div>
        <button
          onClick={onNavigateToTimeOff}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Go to Time Off</span>
        </button>
      </div>

      {/* Attendance Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs font-semibold text-slate-500">Present Today</span>
          <p className="text-2xl font-bold text-emerald-600 mt-1">94.5%</p>
          <span className="text-[11px] text-slate-400">5 out of 6 active staff</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs font-semibold text-slate-500">On Scheduled Leave</span>
          <p className="text-2xl font-bold text-blue-600 mt-1">1</p>
          <span className="text-[11px] text-slate-400">Approved time off today</span>
        </div>
        <div className="bg-white border border-slate-200 rounded-lg p-4">
          <span className="text-xs font-semibold text-slate-500">Average Daily Hours</span>
          <p className="text-2xl font-bold text-slate-800 mt-1">8h 12m</p>
          <span className="text-[11px] text-slate-400">Work week on track</span>
        </div>
      </div>

      {/* Daily Logs Table */}
      <div className="bg-white border border-slate-200 rounded-lg overflow-hidden">
        <div className="px-4 py-3 border-b border-slate-100 bg-slate-50/50">
          <span className="text-xs font-semibold text-slate-800">
            Today's Check-in Log
          </span>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-[11px] font-semibold text-slate-500 uppercase">
                <th className="py-2.5 px-4">Employee</th>
                <th className="py-2.5 px-4">Check In</th>
                <th className="py-2.5 px-4">Check Out</th>
                <th className="py-2.5 px-4">Working Hours</th>
                <th className="py-2.5 px-4">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-slate-700">
              {employees.map((emp, index) => (
                <tr key={emp.id} className="hover:bg-slate-50">
                  <td className="py-2.5 px-4 font-medium text-slate-900 flex items-center gap-2">
                    <img
                      src={emp.avatar}
                      alt={emp.name}
                      className="w-6 h-6 rounded-full object-cover"
                    />
                    <span>{emp.name}</span>
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">
                    {index === 1 ? 'On Leave' : '09:02 AM'}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">
                    {index === 1 ? '-' : '05:35 PM'}
                  </td>
                  <td className="py-2.5 px-4 text-slate-600">
                    {index === 1 ? '-' : '8h 33m'}
                  </td>
                  <td className="py-2.5 px-4">
                    {index === 1 ? (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-blue-50 text-blue-700 border border-blue-200">
                        On Time Off
                      </span>
                    ) : (
                      <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-emerald-50 text-emerald-700 border border-emerald-200">
                        Present
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
