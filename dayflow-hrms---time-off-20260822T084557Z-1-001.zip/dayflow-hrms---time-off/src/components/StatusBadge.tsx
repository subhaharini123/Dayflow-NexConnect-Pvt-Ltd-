import React from 'react';
import { LeaveStatus } from '../types';

interface StatusBadgeProps {
  status: LeaveStatus;
  size?: 'sm' | 'md';
}

export const StatusBadge: React.FC<StatusBadgeProps> = ({ status, size = 'sm' }) => {
  const sizeClasses = size === 'sm' ? 'px-2.5 py-0.5 text-xs' : 'px-3 py-1 text-xs';

  if (status === 'Approved') {
    return (
      <span
        id={`status-badge-${status.toLowerCase()}`}
        className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/70 ${sizeClasses}`}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shrink-0"></span>
        Approved
      </span>
    );
  }

  if (status === 'Rejected') {
    return (
      <span
        id={`status-badge-${status.toLowerCase()}`}
        className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-rose-50 text-rose-700 border border-rose-200/70 ${sizeClasses}`}
      >
        <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shrink-0"></span>
        Rejected
      </span>
    );
  }

  return (
    <span
      id="status-badge-pending"
      className={`inline-flex items-center gap-1.5 font-medium rounded-full bg-amber-50 text-amber-700 border border-amber-200/80 ${sizeClasses}`}
    >
      <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shrink-0"></span>
      Pending
    </span>
  );
};
