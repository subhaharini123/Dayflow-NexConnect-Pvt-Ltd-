import React, { useState } from 'react';
import { Employee } from '../types';
import { Search, Mail, Building, UserCheck, Calendar } from 'lucide-react';

interface EmployeesViewProps {
  employees: Employee[];
  onNavigateToTimeOff: () => void;
}

export const EmployeesView: React.FC<EmployeesViewProps> = ({
  employees,
  onNavigateToTimeOff,
}) => {
  const [search, setSearch] = useState('');

  const filtered = employees.filter(
    (e) =>
      e.name.toLowerCase().includes(search.toLowerCase()) ||
      e.department.toLowerCase().includes(search.toLowerCase()) ||
      e.roleTitle.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div id="employees-page-container" className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Employees</h1>
          <p className="text-xs text-slate-500 mt-1">
            Dayflow organization directory & team roster
          </p>
        </div>
        <button
          onClick={onNavigateToTimeOff}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors"
        >
          <Calendar className="w-3.5 h-3.5" />
          <span>Manage Time Off</span>
        </button>
      </div>

      <div className="bg-white p-3 rounded-lg border border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <div className="relative max-w-sm">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search employee by name, department, or title..."
            className="w-full pl-8.5 pr-3 py-1.5 text-xs rounded-md border border-slate-300 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 bg-white"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filtered.map((emp) => (
          <div
            key={emp.id}
            id={`employee-card-${emp.id}`}
            className="bg-white border border-slate-200 rounded-lg p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)] flex flex-col justify-between"
          >
            <div className="flex items-start gap-3">
              <img
                src={emp.avatar}
                alt={emp.name}
                className="w-10 h-10 rounded-full object-cover ring-1 ring-slate-200 shrink-0"
              />
              <div className="overflow-hidden">
                <h3 className="text-sm font-semibold text-slate-900 truncate">
                  {emp.name}
                </h3>
                <p className="text-xs text-slate-600 truncate">{emp.roleTitle}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{emp.department}</p>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span className="flex items-center gap-1">
                <Mail className="w-3 h-3 text-slate-400" />
                <span className="truncate max-w-[130px]">{emp.email}</span>
              </span>
              <span className="font-semibold text-slate-700">
                PTO: {emp.balances.paidTimeOffTotal - emp.balances.paidTimeOffUsed}d
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
