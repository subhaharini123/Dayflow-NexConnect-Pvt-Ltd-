import React, { useState, useEffect } from 'react';
import { LeaveRequest } from '../types';
import { formatDateDDMMYYYY } from '../utils/dateUtils';
import { X, AlertTriangle } from 'lucide-react';

interface RejectReasonModalProps {
  request: LeaveRequest | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirmReject: (request: LeaveRequest, reason: string) => void;
}

export const RejectReasonModal: React.FC<RejectReasonModalProps> = ({
  request,
  isOpen,
  onClose,
  onConfirmReject,
}) => {
  const [reason, setReason] = useState('');

  useEffect(() => {
    if (isOpen) {
      setReason('');
    }
  }, [isOpen]);

  if (!isOpen || !request) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onConfirmReject(request, reason.trim());
    onClose();
  };

  return (
    <div
      id="reject-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="reject-modal"
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        <div className="px-5 py-4 border-b border-slate-100 flex items-center justify-between bg-rose-50/40">
          <div className="flex items-center gap-2 text-rose-800">
            <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0" />
            <h3 className="text-sm font-semibold">Reject Time Off Request</h3>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-5 space-y-3.5">
          <div className="text-xs text-slate-600 bg-slate-50 p-3 rounded-lg border border-slate-200/60">
            <p className="font-semibold text-slate-800">{request.employeeName}</p>
            <p className="text-slate-500 mt-0.5">
              {request.leaveType} • {formatDateDDMMYYYY(request.startDate)} ({request.days} {request.days === 1 ? 'day' : 'days'})
            </p>
          </div>

          <div>
            <label
              htmlFor="rejection-reason-input"
              className="block text-xs font-semibold text-slate-700 mb-1"
            >
              Rejection Reason / Notes for Employee <span className="text-slate-400 font-normal">(Optional)</span>
            </label>
            <textarea
              id="rejection-reason-input"
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="e.g. Critical release scheduled on this date; please coordinate with team lead..."
              className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 placeholder-slate-400 bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20 focus:border-rose-500 resize-none"
            />
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              id="cancel-reject-btn"
              onClick={onClose}
              className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="confirm-reject-btn"
              className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-700 active:bg-rose-800 transition-colors shadow-xs"
            >
              Confirm Rejection
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
