import React from 'react';
import { Employee, LeaveRequest } from '../types';
import { Calendar, Stethoscope, Clock, CheckCircle2, AlertCircle } from 'lucide-react';

interface LeaveAllocationCardsProps {
  currentUser: Employee;
  isAdminView: boolean;
  allRequests?: LeaveRequest[];
}

export const LeaveAllocationCards: React.FC<LeaveAllocationCardsProps> = ({
  currentUser,
  isAdminView,
  allRequests = [],
}) => {
  const { balances } = currentUser;
  const ptoAvailable = balances.paidTimeOffTotal - balances.paidTimeOffUsed;
  const sickAvailable = balances.sickTimeOffTotal - balances.sickTimeOffUsed;

  const pendingCount = allRequests.filter((r) => r.status === 'Pending').length;
  const approvedThisMonth = allRequests.filter((r) => r.status === 'Approved').length;

  if (isAdminView) {
    return (
      <div id="admin-allocation-cards" className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-6">
        {/* Paid Time Off Card */}
        <div className="bg-white border border-slate-200/90 rounded-lg p-3.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Paid Time Off</span>
            <Calendar className="w-4 h-4 text-blue-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">24</span>
            <span className="text-xs text-slate-500 font-medium">Days Available</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            Standard 28-day annual base
          </p>
        </div>

        {/* Sick Time Off Card */}
        <div className="bg-white border border-slate-200/90 rounded-lg p-3.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Sick Time Off</span>
            <Stethoscope className="w-4 h-4 text-teal-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-slate-900">07</span>
            <span className="text-xs text-slate-500 font-medium">Days Available</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">
            10-day yearly medical allowance
          </p>
        </div>

        {/* Pending Requests */}
        <div className="bg-white border border-slate-200/90 rounded-lg p-3.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Pending Reviews</span>
            <AlertCircle className="w-4 h-4 text-amber-500" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-amber-600">{pendingCount}</span>
            <span className="text-xs text-slate-500 font-medium">
              {pendingCount === 1 ? 'Request pending' : 'Requests pending'}
            </span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Requires HR/Manager action</p>
        </div>

        {/* Approved Records */}
        <div className="bg-white border border-slate-200/90 rounded-lg p-3.5 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">Approved Leaves</span>
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          </div>
          <div className="mt-2 flex items-baseline gap-1.5">
            <span className="text-xl font-bold text-emerald-600">{approvedThisMonth}</span>
            <span className="text-xs text-slate-500 font-medium">Processed</span>
          </div>
          <p className="text-[11px] text-slate-400 mt-1">Active cycle records</p>
        </div>
      </div>
    );
  }

  // Employee View
  return (
    <div id="employee-allocation-cards" className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 mb-6">
      {/* Paid Time Off */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-700">Paid Time Off</span>
          <span className="p-1 rounded bg-blue-50 text-blue-600">
            <Calendar className="w-4 h-4" />
          </span>
        </div>
        <div className="mt-2.5 flex items-baseline gap-1.5">
          <span className="text-2xl font-bold text-slate-900 tracking-tight">
            {ptoAvailable < 10 ? `0${ptoAvailable}` : ptoAvailable}
          </span>
          <span className="text-xs font-semibold text-slate-600">Days Available</span>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
          <span>Total: {balances.paidTimeOffTotal} days</span>
          <span>Used: {balances.paidTimeOffUsed} days</span>
        </div>
      </div>

      {/* Sick Time Off */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-700">Sick Time Off</span>
          <span className="p-1 rounded bg-teal-50 text-teal-600">
            <Stethoscope className="w-4 h-4" />
          </span>
        </div>
        <div className="mt-2.5 flex items-baseline gap-1.5">
          <span className="text-2xl font-bold text-slate-900 tracking-tight">
            {sickAvailable < 10 ? `0${sickAvailable}` : sickAvailable}
          </span>
          <span className="text-xs font-semibold text-slate-600">Days Available</span>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
          <span>Total: {balances.sickTimeOffTotal} days</span>
          <span>Used: {balances.sickTimeOffUsed} days</span>
        </div>
      </div>

      {/* Unpaid Leave */}
      <div className="bg-white border border-slate-200 rounded-lg p-4 shadow-[0_1px_2px_rgba(0,0,0,0.02)]">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-700">Unpaid Leave</span>
          <span className="p-1 rounded bg-purple-50 text-purple-600">
            <Clock className="w-4 h-4" />
          </span>
        </div>
        <div className="mt-2.5 flex items-baseline gap-1.5">
          <span className="text-lg font-bold text-slate-900 tracking-tight">
            Available
          </span>
          <span className="text-xs text-slate-500 font-medium">(On approval)</span>
        </div>
        <div className="mt-2 flex items-center justify-between text-[11px] text-slate-400">
          <span>Requires manager review</span>
          <span>Used: {balances.unpaidLeaveUsed} days</span>
        </div>
      </div>
    </div>
  );
};
