import React from 'react';
import { LeaveType } from '../types';
import { Calendar, Stethoscope, Clock } from 'lucide-react';

interface LeaveTypeBadgeProps {
  type: LeaveType;
  showIcon?: boolean;
}

export const LeaveTypeBadge: React.FC<LeaveTypeBadgeProps> = ({ type, showIcon = true }) => {
  if (type === 'Paid Time Off') {
    return (
      <span
        id="leave-type-paid"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-slate-700 bg-slate-100/90 border border-slate-200/80 px-2.5 py-0.5 rounded"
      >
        {showIcon && <Calendar className="w-3.5 h-3.5 text-blue-600" />}
        Paid Time Off
      </span>
    );
  }

  if (type === 'Sick Time Off') {
    return (
      <span
        id="leave-type-sick"
        className="inline-flex items-center gap-1.5 text-xs font-medium text-teal-800 bg-teal-50 border border-teal-200/70 px-2.5 py-0.5 rounded"
      >
        {showIcon && <Stethoscope className="w-3.5 h-3.5 text-teal-600" />}
        Sick Time Off
      </span>
    );
  }

  return (
    <span
      id="leave-type-unpaid"
      className="inline-flex items-center gap-1.5 text-xs font-medium text-purple-800 bg-purple-50 border border-purple-200/70 px-2.5 py-0.5 rounded"
    >
      {showIcon && <Clock className="w-3.5 h-3.5 text-purple-600" />}
      Unpaid Leave
    </span>
  );
};
