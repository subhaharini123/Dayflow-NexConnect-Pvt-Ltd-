import React, { useState, useMemo } from 'react';
import { LeaveRequest, Employee, LeaveType, LeaveStatus } from '../types';
import { formatDateDDMMYYYY } from '../utils/dateUtils';
import { StatusBadge } from './StatusBadge';
import { LeaveTypeBadge } from './LeaveTypeBadge';
import { LeaveAllocationCards } from './LeaveAllocationCards';
import {
  Search,
  Filter,
  Plus,
  Check,
  X,
  Eye,
  Calendar,
  RotateCcw,
  UserCheck,
  FileSpreadsheet,
} from 'lucide-react';

interface AdminTimeOffViewProps {
  requests: LeaveRequest[];
  currentUser: Employee;
  onApprove: (request: LeaveRequest) => void;
  onRejectPrompt: (request: LeaveRequest) => void;
  onViewDetails: (request: LeaveRequest) => void;
  onOpenNewRequestModal: () => void;
}

export const AdminTimeOffView: React.FC<AdminTimeOffViewProps> = ({
  requests,
  currentUser,
  onApprove,
  onRejectPrompt,
  onViewDetails,
  onOpenNewRequestModal,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [dateFilter, setDateFilter] = useState<string>('All');

  // Filter requests
  const filteredRequests = useMemo(() => {
    return requests.filter((req) => {
      // Search match
      const matchesSearch =
        req.employeeName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        req.employeeDepartment.toLowerCase().includes(searchQuery.toLowerCase()) ||
        req.reason.toLowerCase().includes(searchQuery.toLowerCase());

      // Type match
      const matchesType = typeFilter === 'All' || req.leaveType === typeFilter;

      // Status match
      const matchesStatus = statusFilter === 'All' || req.status === statusFilter;

      // Date match (simple demo filter: All, 2025-10, 2025-11, etc.)
      const matchesDate =
        dateFilter === 'All' ||
        (dateFilter === 'Oct 2025' && req.startDate.startsWith('2025-10')) ||
        (dateFilter === 'Nov 2025' && req.startDate.startsWith('2025-11')) ||
        (dateFilter === 'Sep 2025' && req.startDate.startsWith('2025-09'));

      return matchesSearch && matchesType && matchesStatus && matchesDate;
    });
  }, [requests, searchQuery, typeFilter, statusFilter, dateFilter]);

  const hasActiveFilters =
    searchQuery !== '' || typeFilter !== 'All' || statusFilter !== 'All' || dateFilter !== 'All';

  const resetFilters = () => {
    setSearchQuery('');
    setTypeFilter('All');
    setStatusFilter('All');
    setDateFilter('All');
  };

  return (
    <div id="admin-time-off-view" className="space-y-6">
      {/* Page Heading & Main Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Time Off</h1>
          <p className="text-xs text-slate-500 mt-1">
            Manage employee leave requests and time-off allocations
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            id="admin-new-request-btn"
            onClick={onOpenNewRequestModal}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>+ New Request</span>
          </button>
        </div>
      </div>

      {/* Allocation Overview Area */}
      <LeaveAllocationCards
        currentUser={currentUser}
        isAdminView={true}
        allRequests={requests}
      />

      {/* Request Filter Bar */}
      <div
        id="admin-filter-bar"
        className="bg-white p-3 rounded-lg border border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)] space-y-3 sm:space-y-0"
      >
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center">
          {/* Search Input */}
          <div className="sm:col-span-4 relative">
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              id="admin-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search employee"
              className="w-full pl-8.5 pr-3 py-1.5 text-xs rounded-md border border-slate-300 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Leave Type Dropdown */}
          <div className="sm:col-span-3">
            <select
              id="admin-leave-type-filter"
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs rounded-md border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="All">Leave Type: All</option>
              <option value="Paid Time Off">Paid Time Off</option>
              <option value="Sick Time Off">Sick Time Off</option>
              <option value="Unpaid Leave">Unpaid Leave</option>
            </select>
          </div>

          {/* Status Dropdown */}
          <div className="sm:col-span-2">
            <select
              id="admin-status-filter"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs rounded-md border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="All">Status: All</option>
              <option value="Pending">Pending</option>
              <option value="Approved">Approved</option>
              <option value="Rejected">Rejected</option>
            </select>
          </div>

          {/* Date Selector */}
          <div className="sm:col-span-2">
            <select
              id="admin-date-filter"
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value)}
              className="w-full py-1.5 px-2.5 text-xs rounded-md border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            >
              <option value="All">Date: All</option>
              <option value="Nov 2025">Nov 2025</option>
              <option value="Oct 2025">Oct 2025</option>
              <option value="Sep 2025">Sep 2025</option>
            </select>
          </div>

          {/* Reset button */}
          <div className="sm:col-span-1 flex justify-end">
            {hasActiveFilters && (
              <button
                id="admin-reset-filters-btn"
                onClick={resetFilters}
                className="w-full sm:w-auto p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded text-xs flex items-center justify-center gap-1 transition-colors"
                title="Reset all filters"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="sm:hidden">Reset</span>
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Admin Request Table */}
      <div
        id="admin-request-table-container"
        className="bg-white rounded-lg border border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)] overflow-hidden"
      >
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-slate-800">
              Leave Requests
            </span>
            <span className="text-[11px] text-slate-500 bg-slate-200/70 px-2 py-0.5 rounded-full font-medium">
              {filteredRequests.length} {filteredRequests.length === 1 ? 'record' : 'records'}
            </span>
          </div>
          {filteredRequests.some((r) => r.status === 'Pending') && (
            <span className="text-[11px] text-amber-700 font-medium">
              Action required for pending requests
            </span>
          )}
        </div>

        {/* Table Content */}
        {filteredRequests.length === 0 ? (
          <div id="admin-empty-state" className="py-12 px-4 text-center">
            <div className="w-10 h-10 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <Calendar className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-slate-800">No time-off requests found</h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              No leave applications matched the selected filter criteria. Try adjusting your filters or search term.
            </p>
            {hasActiveFilters && (
              <button
                onClick={resetFilters}
                className="mt-3.5 text-xs font-medium text-blue-600 hover:text-blue-800"
              >
                Clear all filters
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="admin-leaves-table">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-2.5 px-4">Employee</th>
                  <th className="py-2.5 px-4">Start Date</th>
                  <th className="py-2.5 px-4">End Date</th>
                  <th className="py-2.5 px-4">Time Off Type</th>
                  <th className="py-2.5 px-4 text-center">Days</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredRequests.map((request) => {
                  const isPending = request.status === 'Pending';
                  return (
                    <tr
                      key={request.id}
                      id={`request-row-${request.id}`}
                      className="hover:bg-slate-50/80 transition-colors group cursor-pointer"
                      onClick={() => onViewDetails(request)}
                    >
                      {/* Employee Column */}
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={request.employeeAvatar}
                            alt={request.employeeName}
                            className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200"
                          />
                          <div>
                            <div className="font-semibold text-slate-900 group-hover:text-blue-600 transition-colors">
                              {request.employeeName}
                            </div>
                            <div className="text-[11px] text-slate-400">
                              {request.employeeDepartment}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Start Date */}
                      <td className="py-3 px-4 font-medium text-slate-800 whitespace-nowrap">
                        {formatDateDDMMYYYY(request.startDate)}
                      </td>

                      {/* End Date */}
                      <td className="py-3 px-4 font-medium text-slate-800 whitespace-nowrap">
                        {formatDateDDMMYYYY(request.endDate)}
                      </td>

                      {/* Time Off Type */}
                      <td className="py-3 px-4">
                        <LeaveTypeBadge type={request.leaveType} />
                      </td>

                      {/* Days */}
                      <td className="py-3 px-4 text-center font-semibold text-slate-800">
                        {request.days}
                      </td>

                      {/* Status */}
                      <td className="py-3 px-4">
                        <StatusBadge status={request.status} />
                      </td>

                      {/* Actions */}
                      <td
                        className="py-3 px-4 text-right whitespace-nowrap"
                        onClick={(e) => e.stopPropagation()}
                      >
                        {isPending ? (
                          <div className="flex items-center justify-end gap-1.5">
                            <button
                              id={`approve-btn-${request.id}`}
                              onClick={() => onApprove(request)}
                              className="px-2.5 py-1 text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded transition-colors"
                              title="Approve time-off request"
                            >
                              Approve
                            </button>
                            <button
                              id={`reject-btn-${request.id}`}
                              onClick={() => onRejectPrompt(request)}
                              className="px-2.5 py-1 text-xs font-medium text-rose-700 bg-white hover:bg-rose-50 border border-rose-200 rounded transition-colors"
                              title="Reject request with comment"
                            >
                              Reject
                            </button>
                          </div>
                        ) : (
                          <button
                            id={`view-btn-${request.id}`}
                            onClick={() => onViewDetails(request)}
                            className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded transition-colors"
                          >
                            View
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
