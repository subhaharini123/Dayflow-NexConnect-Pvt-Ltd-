import React, { useState, useEffect } from 'react';
import { Employee, LeaveType, LeaveRequest } from '../types';
import { calculateDaysBetween } from '../utils/dateUtils';
import { X, Calendar, Upload, FileText, AlertCircle, CheckCircle2 } from 'lucide-react';

interface RequestTimeOffModalProps {
  isOpen: boolean;
  onClose: () => void;
  currentUser: Employee;
  allEmployees: Employee[];
  onSubmit: (requestData: Omit<LeaveRequest, 'id' | 'createdAt' | 'status'>) => void;
}

export const RequestTimeOffModal: React.FC<RequestTimeOffModalProps> = ({
  isOpen,
  onClose,
  currentUser,
  allEmployees,
  onSubmit,
}) => {
  const [selectedEmployeeId, setSelectedEmployeeId] = useState(currentUser.id);
  const [leaveType, setLeaveType] = useState<LeaveType>('Paid Time Off');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [remarks, setRemarks] = useState('');
  const [attachment, setAttachment] = useState<{ name: string; size: string } | null>(null);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Sync selected employee with current user when opening or switching
  useEffect(() => {
    if (isOpen) {
      setSelectedEmployeeId(currentUser.id);
      setLeaveType('Paid Time Off');
      
      // Default to today or tomorrow
      const today = new Date();
      const todayStr = today.toISOString().split('T')[0];
      setStartDate(todayStr);
      setEndDate(todayStr);
      setRemarks('');
      setAttachment(null);
      setErrors({});
    }
  }, [isOpen, currentUser]);

  if (!isOpen) return null;

  const targetEmployee =
    allEmployees.find((e) => e.id === selectedEmployeeId) || currentUser;

  // Auto calculate days
  const calculatedDays = calculateDaysBetween(startDate, endDate);

  // Calculate available balance for selected employee
  const getAvailableBalance = (type: LeaveType) => {
    if (type === 'Paid Time Off') {
      return targetEmployee.balances.paidTimeOffTotal - targetEmployee.balances.paidTimeOffUsed;
    }
    if (type === 'Sick Time Off') {
      return targetEmployee.balances.sickTimeOffTotal - targetEmployee.balances.sickTimeOffUsed;
    }
    return 'Unlimited (Subject to approval)';
  };

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setStartDate(val);
    if (errors.startDate) {
      setErrors((prev) => ({ ...prev, startDate: '' }));
    }
    // If end date is empty or before start date, update end date to match start date
    if (!endDate || endDate < val) {
      setEndDate(val);
    }
  };

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value;
    setEndDate(val);
    if (errors.endDate) {
      setErrors((prev) => ({ ...prev, endDate: '' }));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const sizeInKb = Math.round(file.size / 1024);
      setAttachment({
        name: file.name,
        size: sizeInKb > 1024 ? `${(sizeInKb / 1024).toFixed(1)} MB` : `${sizeInKb} KB`,
      });
    }
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};

    if (!leaveType) {
      newErrors.leaveType = 'Please select a leave type.';
    }

    if (!startDate) {
      newErrors.startDate = 'Start date is required.';
    }

    if (!endDate) {
      newErrors.endDate = 'End date is required.';
    }

    if (startDate && endDate && endDate < startDate) {
      newErrors.endDate = 'End date cannot be earlier than start date.';
    }

    if (calculatedDays <= 0) {
      newErrors.days = 'Duration must be at least 1 day.';
    }

    if (!remarks.trim()) {
      newErrors.remarks = 'Please provide a brief reason or remarks.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setIsSubmitting(true);

    const requestData: Omit<LeaveRequest, 'id' | 'createdAt' | 'status'> = {
      employeeId: targetEmployee.id,
      employeeName: targetEmployee.name,
      employeeEmail: targetEmployee.email,
      employeeDepartment: targetEmployee.department,
      employeeAvatar: targetEmployee.avatar,
      leaveType,
      startDate,
      endDate,
      days: calculatedDays,
      reason: remarks.trim(),
      attachmentName: attachment?.name,
      attachmentSize: attachment?.size,
    };

    setTimeout(() => {
      onSubmit(requestData);
      setIsSubmitting(false);
      onClose();
    }, 150);
  };

  return (
    <div
      id="request-time-off-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="request-time-off-modal"
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-lg overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Modal Header */}
        <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div>
            <h3 className="text-base font-semibold text-slate-900">Request Time Off</h3>
            <p className="text-xs text-slate-500 mt-0.5">
              Submit your leave application for manager & HR review
            </p>
          </div>
          <button
            id="close-request-modal-btn"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Modal Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {/* Employee Selector (Shown if HR Admin is applying on behalf, or displayed as static info) */}
          {currentUser.isHRAdmin ? (
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                Apply on behalf of Employee
              </label>
              <select
                id="select-employee-input"
                value={selectedEmployeeId}
                onChange={(e) => setSelectedEmployeeId(e.target.value)}
                className="w-full text-xs rounded-lg border border-slate-300 px-3 py-2 text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500"
              >
                {allEmployees.map((emp) => (
                  <option key={emp.id} value={emp.id}>
                    {emp.name} — {emp.roleTitle} ({emp.department})
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 border border-slate-200/70">
              <div className="flex items-center gap-2.5">
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full object-cover"
                />
                <div>
                  <p className="text-xs font-semibold text-slate-900">{currentUser.name}</p>
                  <p className="text-[11px] text-slate-500">
                    {currentUser.roleTitle} • {currentUser.department}
                  </p>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[10px] uppercase font-semibold text-slate-400 block">
                  PTO Balance
                </span>
                <span className="text-xs font-bold text-slate-800">
                  {currentUser.balances.paidTimeOffTotal - currentUser.balances.paidTimeOffUsed} Days Left
                </span>
              </div>
            </div>
          )}

          {/* Time Off Type */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label
                htmlFor="leave-type-select"
                className="block text-xs font-semibold text-slate-700"
              >
                Time Off Type <span className="text-rose-500">*</span>
              </label>
              <span className="text-[11px] text-slate-500">
                Available:{' '}
                <strong className="text-slate-800 font-semibold">
                  {typeof getAvailableBalance(leaveType) === 'number'
                    ? `${getAvailableBalance(leaveType)} Days`
                    : getAvailableBalance(leaveType)}
                </strong>
              </span>
            </div>
            <select
              id="leave-type-select"
              value={leaveType}
              onChange={(e) => setLeaveType(e.target.value as LeaveType)}
              className={`w-full text-xs rounded-lg border px-3 py-2 text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 ${
                errors.leaveType ? 'border-rose-400' : 'border-slate-300'
              }`}
            >
              <option value="Paid Time Off">Paid Time Off (PTO)</option>
              <option value="Sick Time Off">Sick Time Off</option>
              <option value="Unpaid Leave">Unpaid Leave</option>
            </select>
            {errors.leaveType && (
              <p className="text-rose-500 text-[11px] mt-1">{errors.leaveType}</p>
            )}
          </div>

          {/* Date Range: Start and End Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label
                htmlFor="start-date-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                Start Date <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  id="start-date-input"
                  value={startDate}
                  onChange={handleStartDateChange}
                  className={`w-full text-xs rounded-lg border px-3 py-2 text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 ${
                    errors.startDate ? 'border-rose-400' : 'border-slate-300'
                  }`}
                />
              </div>
              {errors.startDate && (
                <p className="text-rose-500 text-[11px] mt-1">{errors.startDate}</p>
              )}
            </div>

            <div>
              <label
                htmlFor="end-date-input"
                className="block text-xs font-semibold text-slate-700 mb-1.5"
              >
                End Date <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <input
                  type="date"
                  id="end-date-input"
                  value={endDate}
                  min={startDate}
                  onChange={handleEndDateChange}
                  className={`w-full text-xs rounded-lg border px-3 py-2 text-slate-800 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 ${
                    errors.endDate ? 'border-rose-400' : 'border-slate-300'
                  }`}
                />
              </div>
              {errors.endDate && (
                <p className="text-rose-500 text-[11px] mt-1">{errors.endDate}</p>
              )}
            </div>
          </div>

          {/* Auto-calculated duration indicator */}
          <div
            id="duration-calculator-box"
            className="flex items-center justify-between px-3.5 py-2.5 bg-blue-50/70 border border-blue-100 rounded-lg text-xs text-blue-900"
          >
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-blue-600 shrink-0" />
              <span>
                Calculated Duration:{' '}
                <strong className="font-semibold text-blue-950">
                  {calculatedDays > 0 ? `${calculatedDays} ${calculatedDays === 1 ? 'Day' : 'Days'}` : '0 Days'}
                </strong>
              </span>
            </div>
            {calculatedDays > 0 && (
              <span className="text-[11px] font-medium text-blue-700">
                (Inclusive of working dates)
              </span>
            )}
          </div>
          {errors.days && <p className="text-rose-500 text-[11px]">{errors.days}</p>}

          {/* Remarks Textarea */}
          <div>
            <label
              htmlFor="remarks-input"
              className="block text-xs font-semibold text-slate-700 mb-1.5"
            >
              Remarks / Reason <span className="text-rose-500">*</span>
            </label>
            <textarea
              id="remarks-input"
              rows={3}
              value={remarks}
              onChange={(e) => {
                setRemarks(e.target.value);
                if (errors.remarks) setErrors((prev) => ({ ...prev, remarks: '' }));
              }}
              placeholder="Add a reason or additional information for your manager and HR..."
              className={`w-full text-xs rounded-lg border px-3 py-2 text-slate-800 placeholder-slate-400 bg-white focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 resize-none ${
                errors.remarks ? 'border-rose-400' : 'border-slate-300'
              }`}
            />
            {errors.remarks && (
              <p className="text-rose-500 text-[11px] mt-1">{errors.remarks}</p>
            )}
          </div>

          {/* Optional Attachment */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              Attachment <span className="text-slate-400 font-normal">(Optional, e.g. medical certificate for sick leave)</span>
            </label>
            {attachment ? (
              <div className="flex items-center justify-between p-2.5 bg-slate-50 border border-slate-200 rounded-lg text-xs">
                <div className="flex items-center gap-2 overflow-hidden">
                  <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="font-medium text-slate-800 truncate">{attachment.name}</span>
                  <span className="text-[10px] text-slate-400 shrink-0">({attachment.size})</span>
                </div>
                <button
                  type="button"
                  onClick={() => setAttachment(null)}
                  className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            ) : (
              <label
                htmlFor="file-upload-input"
                className="flex items-center justify-center gap-2 p-3 border border-dashed border-slate-300 rounded-lg text-xs text-slate-600 hover:bg-slate-50 hover:border-slate-400 cursor-pointer transition-colors"
              >
                <Upload className="w-4 h-4 text-slate-400" />
                <span>Upload document (PDF, PNG, JPG up to 10MB)</span>
                <input
                  id="file-upload-input"
                  type="file"
                  onChange={handleFileChange}
                  accept=".pdf,.png,.jpg,.jpeg,.doc,.docx"
                  className="hidden"
                />
              </label>
            )}
          </div>

          {/* Modal Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              id="cancel-request-btn"
              onClick={onClose}
              className="px-4 py-2 rounded-lg text-xs font-medium text-slate-700 hover:bg-slate-100 border border-slate-200 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              id="submit-request-btn"
              disabled={isSubmitting}
              className="px-4 py-2 rounded-lg text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 transition-colors shadow-xs"
            >
              {isSubmitting ? 'Submitting...' : 'Submit Request'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
