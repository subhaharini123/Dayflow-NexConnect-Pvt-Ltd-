import React, { useState, useMemo } from 'react';
import { LeaveRequest, Employee } from '../types';
import { formatDateDDMMYYYY } from '../utils/dateUtils';
import { StatusBadge } from './StatusBadge';
import { LeaveTypeBadge } from './LeaveTypeBadge';
import { LeaveAllocationCards } from './LeaveAllocationCards';
import { Plus, Search, Calendar, Eye, FileText, Info } from 'lucide-react';

interface EmployeeTimeOffViewProps {
  requests: LeaveRequest[];
  currentUser: Employee;
  onOpenNewRequestModal: () => void;
  onViewDetails: (request: LeaveRequest) => void;
}

export const EmployeeTimeOffView: React.FC<EmployeeTimeOffViewProps> = ({
  requests,
  currentUser,
  onOpenNewRequestModal,
  onViewDetails,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('All');
  const [statusFilter, setStatusFilter] = useState<string>('All');

  // Filter requests strictly to the logged-in employee only!
  const myRequests = useMemo(() => {
    return requests.filter((r) => r.employeeId === currentUser.id);
  }, [requests, currentUser.id]);

  const filteredMyRequests = useMemo(() => {
    return myRequests.filter((req) => {
      const matchesSearch =
        req.reason.toLowerCase().includes(searchQuery.toLowerCase()) ||
        req.leaveType.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (req.adminComments && req.adminComments.toLowerCase().includes(searchQuery.toLowerCase()));

      const matchesType = typeFilter === 'All' || req.leaveType === typeFilter;
      const matchesStatus = statusFilter === 'All' || req.status === statusFilter;

      return matchesSearch && matchesType && matchesStatus;
    });
  }, [myRequests, searchQuery, typeFilter, statusFilter]);

  return (
    <div id="employee-time-off-view" className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-slate-200">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">My Time Off</h1>
          <p className="text-xs text-slate-500 mt-1">
            View your leave balance and manage time-off requests
          </p>
        </div>
        <button
          id="employee-request-time-off-btn"
          onClick={onOpenNewRequestModal}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-blue-600 hover:bg-blue-700 active:bg-blue-800 rounded-lg shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>+ Request Time Off</span>
        </button>
      </div>

      {/* Leave Balance Area */}
      <LeaveAllocationCards currentUser={currentUser} isAdminView={false} />

      {/* Filter and Search */}
      <div
        id="employee-filter-bar"
        className="bg-white p-3 rounded-lg border border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)] grid grid-cols-1 sm:grid-cols-12 gap-2.5 items-center"
      >
        <div className="sm:col-span-6 relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            id="employee-search-input"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search my time-off requests..."
            className="w-full pl-8.5 pr-3 py-1.5 text-xs rounded-md border border-slate-300 text-slate-800 placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500 bg-white"
          />
        </div>

        <div className="sm:col-span-3">
          <select
            id="employee-type-filter"
            value={typeFilter}
            onChange={(e) => setTypeFilter(e.target.value)}
            className="w-full py-1.5 px-2.5 text-xs rounded-md border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="All">Leave Type: All</option>
            <option value="Paid Time Off">Paid Time Off</option>
            <option value="Sick Time Off">Sick Time Off</option>
            <option value="Unpaid Leave">Unpaid Leave</option>
          </select>
        </div>

        <div className="sm:col-span-3">
          <select
            id="employee-status-filter"
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="w-full py-1.5 px-2.5 text-xs rounded-md border border-slate-300 text-slate-700 bg-white focus:outline-none focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="All">Status: All</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
          </select>
        </div>
      </div>

      {/* Employee Request Table */}
      <div
        id="employee-table-container"
        className="bg-white rounded-lg border border-slate-200 shadow-[0_1px_2px_rgba(0,0,0,0.02)] overflow-hidden"
      >
        <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <span className="text-xs font-semibold text-slate-800">
            My Request History
          </span>
          <span className="text-[11px] text-slate-500 bg-slate-200/70 px-2 py-0.5 rounded-full font-medium">
            {filteredMyRequests.length} {filteredMyRequests.length === 1 ? 'record' : 'records'}
          </span>
        </div>

        {filteredMyRequests.length === 0 ? (
          <div id="employee-empty-state" className="py-14 px-4 text-center">
            <div className="w-11 h-11 rounded-full bg-slate-100 flex items-center justify-center mx-auto text-slate-400 mb-3">
              <Calendar className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-semibold text-slate-800">
              No time-off requests yet
            </h4>
            <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
              Your submitted requests will appear here. Plan your time off by submitting a new application.
            </p>
            <button
              onClick={onOpenNewRequestModal}
              className="mt-4 px-3.5 py-1.5 text-xs font-semibold text-blue-700 bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg transition-colors inline-flex items-center gap-1.5"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Request Time Off</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse" id="employee-leaves-table">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50/70 text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  <th className="py-2.5 px-4">Start Date</th>
                  <th className="py-2.5 px-4">End Date</th>
                  <th className="py-2.5 px-4">Time Off Type</th>
                  <th className="py-2.5 px-4 text-center">Days</th>
                  <th className="py-2.5 px-4">Status</th>
                  <th className="py-2.5 px-4">Remarks</th>
                  <th className="py-2.5 px-4 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs text-slate-700">
                {filteredMyRequests.map((request) => (
                  <tr
                    key={request.id}
                    id={`my-request-row-${request.id}`}
                    onClick={() => onViewDetails(request)}
                    className="hover:bg-slate-50/80 transition-colors cursor-pointer group"
                  >
                    {/* Start Date */}
                    <td className="py-3 px-4 font-medium text-slate-800 whitespace-nowrap">
                      {formatDateDDMMYYYY(request.startDate)}
                    </td>

                    {/* End Date */}
                    <td className="py-3 px-4 font-medium text-slate-800 whitespace-nowrap">
                      {formatDateDDMMYYYY(request.endDate)}
                    </td>

                    {/* Time Off Type */}
                    <td className="py-3 px-4">
                      <LeaveTypeBadge type={request.leaveType} />
                    </td>

                    {/* Days */}
                    <td className="py-3 px-4 text-center font-semibold text-slate-800">
                      {request.days}
                    </td>

                    {/* Status */}
                    <td className="py-3 px-4">
                      <StatusBadge status={request.status} />
                    </td>

                    {/* Remarks snippet */}
                    <td className="py-3 px-4 text-slate-500 max-w-xs truncate">
                      {request.reason}
                    </td>

                    {/* Action */}
                    <td
                      className="py-3 px-4 text-right whitespace-nowrap"
                      onClick={(e) => e.stopPropagation()}
                    >
                      <button
                        onClick={() => onViewDetails(request)}
                        className="px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded transition-colors"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
};
