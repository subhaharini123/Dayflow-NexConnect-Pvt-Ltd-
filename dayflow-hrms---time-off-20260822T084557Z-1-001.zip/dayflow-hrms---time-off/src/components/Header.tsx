import React, { useState, useRef, useEffect } from 'react';
import { ActiveNavTab, Employee, LeaveRequest } from '../types';
import {
  Bell,
  ChevronDown,
  UserCheck,
  Building2,
  Calendar,
  Clock,
  Shield,
  User,
  Check,
} from 'lucide-react';

interface HeaderProps {
  currentTab: ActiveNavTab;
  onTabChange: (tab: ActiveNavTab) => void;
  currentUser: Employee;
  allEmployees: Employee[];
  onSwitchUser: (user: Employee) => void;
  pendingRequestsCount: number;
  recentRequests: LeaveRequest[];
  onSelectRequest: (request: LeaveRequest) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onTabChange,
  currentUser,
  allEmployees,
  onSwitchUser,
  pendingRequestsCount,
  recentRequests,
  onSelectRequest,
}) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showNotifications, setShowNotifications] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const notifRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfileMenu(false);
      }
      if (notifRef.current && !notifRef.current.contains(event.target as Node)) {
        setShowNotifications(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header
      id="main-header"
      className="bg-white border-b border-slate-200 sticky top-0 z-30 select-none shadow-[0_1px_2px_rgba(0,0,0,0.03)]"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-15">
          {/* Left section: Logo and Nav links */}
          <div className="flex items-center gap-8">
            {/* Brand Logo */}
            <div
              id="brand-logo-container"
              className="flex items-center gap-2.5 cursor-pointer py-1"
              onClick={() => onTabChange('time-off')}
            >
              <div className="w-8 h-8 rounded-md bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-sm tracking-tight">
                Df
              </div>
              <div className="flex flex-col">
                <span className="font-semibold text-slate-900 text-base tracking-tight leading-none">
                  Dayflow
                </span>
                <span className="text-[10px] text-slate-400 font-medium tracking-wide uppercase leading-none mt-1">
                  HR Management
                </span>
              </div>
            </div>

            {/* Navigation links */}
            <nav id="top-nav" className="hidden sm:flex items-center space-x-1">
              <button
                id="nav-tab-employees"
                onClick={() => onTabChange('employees')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  currentTab === 'employees'
                    ? 'text-blue-700 bg-blue-50/80 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                Employees
              </button>

              <button
                id="nav-tab-attendance"
                onClick={() => onTabChange('attendance')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors ${
                  currentTab === 'attendance'
                    ? 'text-blue-700 bg-blue-50/80 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                Attendance
              </button>

              <button
                id="nav-tab-time-off"
                onClick={() => onTabChange('time-off')}
                className={`px-3 py-1.5 text-sm font-medium rounded-md transition-colors flex items-center gap-1.5 ${
                  currentTab === 'time-off'
                    ? 'text-blue-700 bg-blue-50 border border-blue-200/60 font-semibold'
                    : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
              >
                <span>Time Off</span>
                {currentUser.isHRAdmin && pendingRequestsCount > 0 && (
                  <span
                    id="nav-pending-badge"
                    className="ml-0.5 inline-flex items-center justify-center px-1.5 py-0.2 text-[10px] font-bold text-amber-700 bg-amber-100 rounded-full"
                  >
                    {pendingRequestsCount}
                  </span>
                )}
              </button>
            </nav>
          </div>

          {/* Right section: Role switcher, Notifications, and Profile */}
          <div className="flex items-center gap-3">
            {/* Quick Role Switcher Pill */}
            <div className="relative" ref={profileRef}>
              <button
                id="user-profile-menu-button"
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 hover:border-slate-300 bg-white hover:bg-slate-50 text-slate-800 transition-all text-left group"
                title="Switch role or user"
              >
                <img
                  src={currentUser.avatar}
                  alt={currentUser.name}
                  className="w-7 h-7 rounded-full object-cover ring-1 ring-slate-200"
                />
                <div className="hidden md:flex flex-col">
                  <span className="text-xs font-semibold text-slate-900 leading-tight">
                    {currentUser.name}
                  </span>
                  <span className="text-[11px] text-slate-500 leading-tight flex items-center gap-1">
                    {currentUser.isHRAdmin ? (
                      <span className="inline-flex items-center text-blue-600 font-medium">
                        <Shield className="w-2.5 h-2.5 mr-0.5" /> Admin / HR
                      </span>
                    ) : (
                      <span className="inline-flex items-center text-slate-500 font-normal">
                        <User className="w-2.5 h-2.5 mr-0.5" /> Employee
                      </span>
                    )}
                  </span>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 ml-0.5" />
              </button>

              {/* Profile & Role Switch Dropdown */}
              {showProfileMenu && (
                <div
                  id="user-profile-dropdown"
                  className="absolute right-0 mt-2 w-72 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95 duration-150"
                >
                  <div className="px-3 py-2 border-b border-slate-100 mb-1">
                    <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Current Perspective
                    </p>
                    <div className="flex items-center gap-2 mt-1.5">
                      <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                      <p className="text-sm font-semibold text-slate-900">
                        {currentUser.name}
                      </p>
                      <span
                        className={`text-[10px] px-1.5 py-0.5 rounded font-medium ${
                          currentUser.isHRAdmin
                            ? 'bg-blue-100 text-blue-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {currentUser.isHRAdmin ? 'HR Admin' : 'Employee'}
                      </span>
                    </div>
                    <p className="text-xs text-slate-500 mt-0.5">{currentUser.email}</p>
                    <p className="text-xs text-slate-500">{currentUser.roleTitle} • {currentUser.department}</p>
                  </div>

                  <div className="px-3 py-1.5">
                    <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-1">
                      Switch Role / User
                    </p>
                    <p className="text-xs text-slate-500 mb-2">
                      Easily test both Admin/HR review flow and Employee submission flow:
                    </p>

                    <div className="space-y-1">
                      {allEmployees.map((emp) => {
                        const isSelected = emp.id === currentUser.id;
                        return (
                          <button
                            key={emp.id}
                            id={`switch-user-${emp.id}`}
                            onClick={() => {
                              onSwitchUser(emp);
                              setShowProfileMenu(false);
                            }}
                            className={`w-full flex items-center justify-between px-2.5 py-1.5 rounded-md text-xs transition-colors ${
                              isSelected
                                ? 'bg-blue-50 text-blue-900 font-semibold'
                                : 'text-slate-700 hover:bg-slate-100'
                            }`}
                          >
                            <div className="flex items-center gap-2 text-left">
                              <img
                                src={emp.avatar}
                                alt={emp.name}
                                className="w-5 h-5 rounded-full object-cover"
                              />
                              <div>
                                <span>{emp.name}</span>
                                <span className="text-[10px] text-slate-400 ml-1.5">
                                  ({emp.isHRAdmin ? 'Admin/HR' : emp.roleTitle.split(' ')[0]})
                                </span>
                              </div>
                            </div>
                            {isSelected && <Check className="w-3.5 h-3.5 text-blue-600" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Notification Bell */}
            <div className="relative" ref={notifRef}>
              <button
                id="notifications-button"
                onClick={() => setShowNotifications(!showNotifications)}
                className="relative p-2 text-slate-500 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="View notifications"
              >
                <Bell className="w-4.5 h-4.5" />
                {pendingRequestsCount > 0 && (
                  <span
                    id="notification-indicator-dot"
                    className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-500 rounded-full ring-2 ring-white"
                  ></span>
                )}
              </button>

              {/* Notification Popup */}
              {showNotifications && (
                <div
                  id="notifications-dropdown"
                  className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in duration-150"
                >
                  <div className="px-4 py-2 border-b border-slate-100 flex items-center justify-between">
                    <span className="text-xs font-semibold text-slate-800">
                      Notifications
                    </span>
                    <span className="text-[11px] text-slate-500">
                      {pendingRequestsCount} Pending Review
                    </span>
                  </div>

                  <div className="max-h-72 overflow-y-auto divide-y divide-slate-100">
                    {recentRequests.length === 0 ? (
                      <div className="py-6 text-center text-xs text-slate-500">
                        No recent notifications
                      </div>
                    ) : (
                      recentRequests.slice(0, 4).map((req) => (
                        <div
                          key={req.id}
                          id={`notif-item-${req.id}`}
                          onClick={() => {
                            onSelectRequest(req);
                            setShowNotifications(false);
                          }}
                          className="px-4 py-2.5 hover:bg-slate-50 cursor-pointer text-left transition-colors"
                        >
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-medium text-slate-900">
                              {req.employeeName}
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {req.leaveType}
                            </span>
                          </div>
                          <p className="text-xs text-slate-600 line-clamp-1 mt-0.5">
                            {req.reason}
                          </p>
                          <div className="flex items-center justify-between mt-1 text-[10px] text-slate-400">
                            <span>{req.days} {req.days === 1 ? 'day' : 'days'}</span>
                            <span
                              className={
                                req.status === 'Pending'
                                  ? 'text-amber-600 font-medium'
                                  : req.status === 'Approved'
                                  ? 'text-emerald-600'
                                  : 'text-rose-600'
                              }
                            >
                              {req.status}
                            </span>
                          </div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation bar */}
        <div className="sm:hidden flex items-center space-x-1 pb-2 pt-1 border-t border-slate-100 overflow-x-auto">
          <button
            onClick={() => onTabChange('employees')}
            className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
              currentTab === 'employees'
                ? 'text-blue-700 bg-blue-50 font-semibold'
                : 'text-slate-600'
            }`}
          >
            Employees
          </button>
          <button
            onClick={() => onTabChange('attendance')}
            className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap ${
              currentTab === 'attendance'
                ? 'text-blue-700 bg-blue-50 font-semibold'
                : 'text-slate-600'
            }`}
          >
            Attendance
          </button>
          <button
            onClick={() => onTabChange('time-off')}
            className={`px-3 py-1 text-xs font-medium rounded-md whitespace-nowrap flex items-center gap-1 ${
              currentTab === 'time-off'
                ? 'text-blue-700 bg-blue-50 font-semibold'
                : 'text-slate-600'
            }`}
          >
            <span>Time Off</span>
            {currentUser.isHRAdmin && pendingRequestsCount > 0 && (
              <span className="px-1.5 py-0.2 text-[10px] font-bold text-amber-700 bg-amber-100 rounded-full">
                {pendingRequestsCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
