import React from 'react';
import { LeaveRequest, Employee } from '../types';
import { formatDateMedium } from '../utils/dateUtils';
import { StatusBadge } from './StatusBadge';
import { LeaveTypeBadge } from './LeaveTypeBadge';
import { X, Calendar, Clock, User, FileText, Check, AlertCircle, MessageSquare } from 'lucide-react';

interface RequestDetailsModalProps {
  request: LeaveRequest | null;
  onClose: () => void;
  currentUser: Employee;
  onApprove: (request: LeaveRequest) => void;
  onReject: (request: LeaveRequest) => void;
}

export const RequestDetailsModal: React.FC<RequestDetailsModalProps> = ({
  request,
  onClose,
  currentUser,
  onApprove,
  onReject,
}) => {
  if (!request) return null;

  const isPending = request.status === 'Pending';
  const canAdminister = currentUser.isHRAdmin && isPending;

  return (
    <div
      id="request-details-modal-backdrop"
      className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4"
    >
      <div
        id="request-details-modal"
        className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold text-slate-900">Time Off Request</h3>
            <span className="text-xs text-slate-400">#{request.id}</span>
          </div>
          <button
            id="close-details-modal-btn"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 p-1 rounded hover:bg-slate-100 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4 text-xs">
          {/* Employee Info */}
          <div className="flex items-center justify-between p-3 bg-slate-50 rounded-lg border border-slate-200/60">
            <div className="flex items-center gap-2.5">
              <img
                src={request.employeeAvatar}
                alt={request.employeeName}
                className="w-9 h-9 rounded-full object-cover ring-1 ring-slate-200"
              />
              <div>
                <p className="font-semibold text-slate-900 text-sm">
                  {request.employeeName}
                </p>
                <p className="text-slate-500 text-[11px]">
                  {request.employeeDepartment} • {request.employeeEmail}
                </p>
              </div>
            </div>
            <StatusBadge status={request.status} />
          </div>

          {/* Key Details Grid */}
          <div className="grid grid-cols-2 gap-3 py-1">
            <div className="p-2.5 rounded-lg border border-slate-100 bg-white">
              <span className="text-[11px] font-medium text-slate-400 block mb-1">
                Time Off Type
              </span>
              <LeaveTypeBadge type={request.leaveType} />
            </div>

            <div className="p-2.5 rounded-lg border border-slate-100 bg-white">
              <span className="text-[11px] font-medium text-slate-400 block mb-1">
                Allocation / Days
              </span>
              <span className="font-semibold text-slate-800 text-xs">
                {request.days} {request.days === 1 ? 'Day' : 'Days'}
              </span>
            </div>
          </div>

          {/* Validity Period */}
          <div className="p-3 bg-slate-50/70 border border-slate-200/70 rounded-lg">
            <span className="text-[11px] font-medium text-slate-400 block mb-1">
              Validity Period
            </span>
            <div className="flex items-center gap-2 text-slate-800 font-semibold">
              <Calendar className="w-3.5 h-3.5 text-blue-600 shrink-0" />
              <span>
                {formatDateMedium(request.startDate)}
                {request.startDate !== request.endDate && ` – ${formatDateMedium(request.endDate)}`}
              </span>
            </div>
          </div>

          {/* Reason */}
          <div>
            <span className="text-[11px] font-medium text-slate-400 block mb-1">
              Reason / Remarks
            </span>
            <div className="p-3 bg-slate-50 border border-slate-200/70 rounded-lg text-slate-700 leading-relaxed">
              {request.reason || 'No additional remarks provided.'}
            </div>
          </div>

          {/* Attached Document */}
          {request.attachmentName && (
            <div>
              <span className="text-[11px] font-medium text-slate-400 block mb-1">
                Attached Document
              </span>
              <div className="flex items-center justify-between p-2.5 bg-blue-50/50 border border-blue-100 rounded-lg">
                <div className="flex items-center gap-2 overflow-hidden">
                  <FileText className="w-4 h-4 text-blue-600 shrink-0" />
                  <span className="font-medium text-slate-800 truncate">
                    {request.attachmentName}
                  </span>
                  {request.attachmentSize && (
                    <span className="text-[10px] text-slate-400">
                      ({request.attachmentSize})
                    </span>
                  )}
                </div>
                <span className="text-[11px] text-blue-700 font-medium hover:underline cursor-pointer">
                  View file
                </span>
              </div>
            </div>
          )}

          {/* Admin Comments (if rejected or reviewed) */}
          {request.adminComments && (
            <div className="p-3 bg-rose-50/60 border border-rose-200/70 rounded-lg">
              <div className="flex items-center gap-1.5 text-rose-800 font-medium mb-1">
                <MessageSquare className="w-3.5 h-3.5 text-rose-600" />
                <span>Admin Review Remarks</span>
              </div>
              <p className="text-slate-700 text-xs leading-relaxed">
                {request.adminComments}
              </p>
              {request.reviewedBy && (
                <p className="text-[10px] text-slate-400 mt-1">
                  Reviewed by {request.reviewedBy}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="px-5 py-3.5 bg-slate-50 border-t border-slate-100 flex items-center justify-end gap-2">
          {canAdminister ? (
            <>
              <button
                type="button"
                id="modal-reject-btn"
                onClick={() => {
                  onClose();
                  onReject(request);
                }}
                className="px-3.5 py-1.5 rounded-lg text-xs font-medium text-rose-700 bg-white hover:bg-rose-50 border border-rose-300 transition-colors"
              >
                Reject
              </button>
              <button
                type="button"
                id="modal-approve-btn"
                onClick={() => {
                  onApprove(request);
                  onClose();
                }}
                className="px-3.5 py-1.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-700 transition-colors shadow-xs flex items-center gap-1"
              >
                <Check className="w-3.5 h-3.5" />
                Approve
              </button>
            </>
          ) : (
            <button
              type="button"
              id="modal-close-btn"
              onClick={onClose}
              className="px-4 py-1.5 rounded-lg text-xs font-medium text-slate-700 bg-white hover:bg-slate-100 border border-slate-200 transition-colors"
            >
              Close
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
