import React, { useState } from 'react';
import { ActiveNavTab, Employee, LeaveRequest, LeaveStatus } from './types';
import { INITIAL_EMPLOYEES, INITIAL_LEAVE_REQUESTS } from './data/mockData';
import { Header } from './components/Header';
import { AdminTimeOffView } from './components/AdminTimeOffView';
import { EmployeeTimeOffView } from './components/EmployeeTimeOffView';
import { RequestTimeOffModal } from './components/RequestTimeOffModal';
import { RequestDetailsModal } from './components/RequestDetailsModal';
import { RejectReasonModal } from './components/RejectReasonModal';
import { ToastContainer, ToastMessage } from './components/Toast';
import { EmployeesView } from './components/EmployeesView';
import { AttendanceView } from './components/AttendanceView';
import { Shield, User, ArrowRightLeft, Sparkles, Check } from 'lucide-react';

export default function App() {
  // Navigation & Role State
  const [currentTab, setCurrentTab] = useState<ActiveNavTab>('time-off');
  const [employees, setEmployees] = useState<Employee[]>(INITIAL_EMPLOYEES);
  
  // Default to Admin or Arun Kumar (Employee)
  // Let's start with Sarah Jenkins (Admin) or Arun Kumar (Employee)
  // Admin is first in the list
  const [currentUser, setCurrentUser] = useState<Employee>(INITIAL_EMPLOYEES[0]);
  
  // Leave Requests state
  const [requests, setRequests] = useState<LeaveRequest[]>(INITIAL_LEAVE_REQUESTS);

  // Modals state
  const [isRequestModalOpen, setIsRequestModalOpen] = useState(false);
  const [selectedRequestForDetails, setSelectedRequestForDetails] = useState<LeaveRequest | null>(null);
  const [selectedRequestForReject, setSelectedRequestForReject] = useState<LeaveRequest | null>(null);

  // Toasts notification state
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = (type: 'success' | 'error' | 'info', title: string, message?: string) => {
    const id = Date.now().toString() + Math.random().toString(36).substring(2, 6);
    setToasts((prev) => [...prev, { id, type, title, message }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Quick switch role between Admin and standard Employee (Arun Kumar)
  const toggleRole = () => {
    if (currentUser.isHRAdmin) {
      const employeeUser = employees.find((e) => !e.isHRAdmin) || employees[1];
      setCurrentUser(employeeUser);
      addToast(
        'info',
        `Switched to Employee View (${employeeUser.name})`,
        'You are now viewing time-off balances and submission flow as an employee.'
      );
    } else {
      const adminUser = employees.find((e) => e.isHRAdmin) || employees[0];
      setCurrentUser(adminUser);
      addToast(
        'info',
        `Switched to Admin / HR View (${adminUser.name})`,
        'You now have administrative access to approve/reject all leave requests.'
      );
    }
  };

  // Handle Approve Request
  const handleApproveRequest = (request: LeaveRequest) => {
    const updatedRequests = requests.map((r) => {
      if (r.id === request.id) {
        return {
          ...r,
          status: 'Approved' as LeaveStatus,
          reviewedBy: currentUser.name,
          reviewedAt: new Date().toISOString(),
        };
      }
      return r;
    });

    setRequests(updatedRequests);

    // If modal is open for this request, update it
    if (selectedRequestForDetails && selectedRequestForDetails.id === request.id) {
      setSelectedRequestForDetails((prev) =>
        prev
          ? {
              ...prev,
              status: 'Approved',
              reviewedBy: currentUser.name,
              reviewedAt: new Date().toISOString(),
            }
          : null
      );
    }

    // Deduct leave balance for the employee if Paid or Sick
    setEmployees((prev) =>
      prev.map((emp) => {
        if (emp.id === request.employeeId) {
          const balances = { ...emp.balances };
          if (request.leaveType === 'Paid Time Off') {
            balances.paidTimeOffUsed += request.days;
          } else if (request.leaveType === 'Sick Time Off') {
            balances.sickTimeOffUsed += request.days;
          } else {
            balances.unpaidLeaveUsed += request.days;
          }
          return { ...emp, balances };
        }
        return emp;
      })
    );

    addToast(
      'success',
      'Leave Request Approved',
      `Time-off request for ${request.employeeName} (${request.days} ${request.days === 1 ? 'day' : 'days'}) has been approved.`
    );
  };

  // Handle Reject Request with optional comment
  const handleConfirmReject = (request: LeaveRequest, reason: string) => {
    const updatedRequests = requests.map((r) => {
      if (r.id === request.id) {
        return {
          ...r,
          status: 'Rejected' as LeaveStatus,
          adminComments: reason || 'Request rejected by HR / Manager.',
          reviewedBy: currentUser.name,
          reviewedAt: new Date().toISOString(),
        };
      }
      return r;
    });

    setRequests(updatedRequests);

    // If modal is open for this request, update it
    if (selectedRequestForDetails && selectedRequestForDetails.id === request.id) {
      setSelectedRequestForDetails((prev) =>
        prev
          ? {
              ...prev,
              status: 'Rejected',
              adminComments: reason || 'Request rejected by HR / Manager.',
              reviewedBy: currentUser.name,
              reviewedAt: new Date().toISOString(),
            }
          : null
      );
    }

    addToast(
      'error',
      'Leave Request Rejected',
      `Time-off request for ${request.employeeName} has been rejected.${reason ? ` Note: "${reason}"` : ''}`
    );
  };

  // Handle Submitting a New Request (Employee or Admin on behalf)
  const handleSubmitNewRequest = (
    requestData: Omit<LeaveRequest, 'id' | 'createdAt' | 'status'>
  ) => {
    const newRequest: LeaveRequest = {
      ...requestData,
      id: `req-${Date.now()}`,
      status: 'Pending',
      createdAt: new Date().toISOString(),
    };

    setRequests((prev) => [newRequest, ...prev]);

    addToast(
      'success',
      'Time-off request submitted successfully.',
      `Your request for ${newRequest.days} ${newRequest.days === 1 ? 'day' : 'days'} (${newRequest.leaveType}) is now pending review.`
    );
  };

  const pendingCount = requests.filter((r) => r.status === 'Pending').length;

  return (
    <div id="dayflow-hrms-root" className="min-h-screen bg-slate-50/80 text-slate-900 flex flex-col font-sans antialiased">
      {/* Quick Perspective Switcher Banner */}
      <div
        id="perspective-mode-banner"
        className="bg-slate-900 text-slate-200 px-4 py-1.5 text-xs flex flex-wrap items-center justify-between border-b border-slate-800"
      >
        <div className="flex items-center gap-2">
          <span className="font-semibold text-white tracking-wide flex items-center gap-1.5">
            {currentUser.isHRAdmin ? (
              <span className="inline-flex items-center text-blue-400">
                <Shield className="w-3.5 h-3.5 mr-1" /> Admin / HR Perspective
              </span>
            ) : (
              <span className="inline-flex items-center text-emerald-400">
                <User className="w-3.5 h-3.5 mr-1" /> Employee Perspective ({currentUser.name})
              </span>
            )}
          </span>
          <span className="text-slate-400 hidden sm:inline">•</span>
          <span className="text-slate-300 hidden sm:inline">
            {currentUser.isHRAdmin
              ? 'Viewing all company leave requests, approvals, and allocations'
              : 'Viewing personal leave balances, submission form, and request history'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            id="toggle-perspective-btn"
            onClick={toggleRole}
            className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-200 border border-slate-700 text-xs font-medium transition-colors cursor-pointer"
          >
            <ArrowRightLeft className="w-3 h-3 text-blue-400" />
            <span>Switch to {currentUser.isHRAdmin ? 'Employee View' : 'Admin/HR View'}</span>
          </button>
        </div>
      </div>

      {/* Main App Header */}
      <Header
        currentTab={currentTab}
        onTabChange={setCurrentTab}
        currentUser={currentUser}
        allEmployees={employees}
        onSwitchUser={(user) => {
          setCurrentUser(user);
          addToast(
            'info',
            `Switched to ${user.name}`,
            `Now viewing as ${user.name} (${user.isHRAdmin ? 'Admin/HR' : user.roleTitle})`
          );
        }}
        pendingRequestsCount={pendingCount}
        recentRequests={requests}
        onSelectRequest={(req) => setSelectedRequestForDetails(req)}
      />

      {/* Main Content Area */}
      <main id="main-content" className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {currentTab === 'time-off' && (
          <>
            {currentUser.isHRAdmin ? (
              <AdminTimeOffView
                requests={requests}
                currentUser={currentUser}
                onApprove={handleApproveRequest}
                onRejectPrompt={(req) => setSelectedRequestForReject(req)}
                onViewDetails={(req) => setSelectedRequestForDetails(req)}
                onOpenNewRequestModal={() => setIsRequestModalOpen(true)}
              />
            ) : (
              <EmployeeTimeOffView
                requests={requests}
                currentUser={currentUser}
                onOpenNewRequestModal={() => setIsRequestModalOpen(true)}
                onViewDetails={(req) => setSelectedRequestForDetails(req)}
              />
            )}
          </>
        )}

        {currentTab === 'employees' && (
          <EmployeesView
            employees={employees}
            onNavigateToTimeOff={() => setCurrentTab('time-off')}
          />
        )}

        {currentTab === 'attendance' && (
          <AttendanceView
            employees={employees}
            onNavigateToTimeOff={() => setCurrentTab('time-off')}
          />
        )}
      </main>

      {/* Footer Note */}
      <footer className="border-t border-slate-200 bg-white py-3 text-center text-xs text-slate-400">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Dayflow Human Resource Management System • Time Off & Leave Management</span>
          <span>Version 2.4.0 (Enterprise)</span>
        </div>
      </footer>

      {/* Request Time Off Form Modal */}
      <RequestTimeOffModal
        isOpen={isRequestModalOpen}
        onClose={() => setIsRequestModalOpen(false)}
        currentUser={currentUser}
        allEmployees={employees}
        onSubmit={handleSubmitNewRequest}
      />

      {/* Request Details View Modal */}
      <RequestDetailsModal
        request={selectedRequestForDetails}
        onClose={() => setSelectedRequestForDetails(null)}
        currentUser={currentUser}
        onApprove={(req) => handleApproveRequest(req)}
        onReject={(req) => {
          setSelectedRequestForDetails(null);
          setSelectedRequestForReject(req);
        }}
      />

      {/* Reject Reason Modal */}
      <RejectReasonModal
        request={selectedRequestForReject}
        isOpen={!!selectedRequestForReject}
        onClose={() => setSelectedRequestForReject(null)}
        onConfirmReject={handleConfirmReject}
      />

      {/* Toast Notification Container */}
      <ToastContainer toasts={toasts} onDismiss={removeToast} />
    </div>
  );
}
